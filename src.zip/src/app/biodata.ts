import { Time } from '@angular/common';

export interface Wagons{
  data:string,
  rake_id:number,
     bpc_no:string,
     creation_date:Date,
      rake_notification_no: string,
      wagon_no: string,
      wagon_type: string,
      wagon_owner: string,
      notification_no:string,
      train_no :string,
       load_stock:string,
        brake_cyli  :number,
        loco_no  :string,
       brake_power  :string,
      opreating_cyli :number,
      eot_time  :Time,

}
export  interface IBiodatas{
    userId:string,
    password:string,
    id:number,
    title:string,
    body:string,
    username: string,
    firstName: string,
    lastName: string,
    token: string,
    email:string,
    user_id:string,
    data:string,

     
      
     
    
    
}
export interface User {
    userId:string,
    userName: string,
    password: string,
    user_id: string,
  }
  export interface jsondata {
    displayName: string;
    disabled?: boolean;
    iconName: string;
    route?: string;
    children?: jsondata [];
    component?: jsondata[];
    userId:string,
    password:string,
    id:number,
    title:string,
    body:string,
    username: string,
    firstName: string,
    lastName: string,
    token: string,
    email:string,
    user_id:string,
    data:string,
  
      url: string,
      icon: string,
  }
  
