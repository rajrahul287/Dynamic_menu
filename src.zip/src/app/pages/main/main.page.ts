import { Component, OnInit, ViewChild } from '@angular/core';
import { IonInfiniteScroll, NavController } from '@ionic/angular';
import { IBiodatas, User } from '../../biodata';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ErrorHandler, NgModule } from '@angular/core';
//import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ViewEncapsulation } from '@angular/core';
import { Ng2SmartTableModule } from 'ng2-smart-table';


@Component({
  selector: 'app-main',
  templateUrl: './main.page.html',
  styleUrls: ['./main.page.scss'],
  encapsulation: ViewEncapsulation.None

})

export class MainPage implements OnInit {
  listItems: any;
  @ViewChild(IonInfiniteScroll) infiniteScroll: IonInfiniteScroll;
  columns: ({ prop: string; name?: string; } | { name: string; prop?: string; })[];
  
rows=[]
  constructor(private http: HttpClient, private navCtrl: NavController, 
    private restservice: AuthenticationService, private ngx: NgxDatatableModule) {
      this.listItems = [
        "1. IONIC",
        "2. FLUTTER",
        "3. ANDROID",
        "4. NODE",
        "5. VUE",
        "6. REACT"
      ];
      

   this.rows = [
      
    ];

   this.http.get('../../../assets/data/techologies.json').subscribe((data:any)=>{
     console.log('Get Data:',data.technologies)
     this.rows=data.technologies
     this.rows=this.rows
   })
    
  }
  onRenderItems(event) {
    console.log(`Moving item from ${event.detail.from} to ${event.detail.to}`);
     let draggedItem = this.listItems.splice(event.detail.from,1)[0];
     this.listItems.splice(event.detail.to,0,draggedItem)
    //this.listItems = reorderArray(this.listItems, event.detail.from, event.detail.to);
    event.detail.complete();
  }
  getList() {
    console.table(this.listItems);
    var str="4. IONIC"
    console.log(str.substring(3))
    str='1. '+str.substring(3)
    console.log(str)

  }
  ngOnInit() {
  
  }

}
