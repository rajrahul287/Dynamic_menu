import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NavController } from '@ionic/angular';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { Ng2SmartTableModule } from 'ng2-smart-table';


@Component({
  selector: 'app-wagondetails',
  templateUrl: './wagondetails.page.html',
  styleUrls: ['./wagondetails.page.scss'],
})
export class WagondetailsPage {
  settings = {
    columns: {
      id: {
        title: 'ID'
      },
      name: {
        title: 'Full Name'
      },
      username: {
        title: 'User Name'
      },
      email: {
        title: 'Email'
      }
    },
    data : [
      {
        id: 1,
        name: "Leanne Graham",
        username: "Bret",
        email: "Sincere@april.biz"
      },
      {
        id: 2,
        name: "Ervin Howell",
        username: "Antonette",
        email: "Shanna@melissa.tv"
      },
      
      // ... list of items
      
      {
        id: 11,
        name: "Nicholas DuBuque",
        username: "Nicholas.Stanton",
        email: "Rey.Padberg@rosamond.biz"
      }
    ]
  };
  rows: any[];
  columns: { name: string; }[];
  constructor(private http: HttpClient, private navCtrl: NavController, 
    private restservice: AuthenticationService, private ng2datatable:Ng2SmartTableModule) { 


      this.rows = [
      
      ];
  
     this.http.get('../../../assets/data/techologies.json').subscribe((data:any)=>{
       console.log('Get Data:',data.technologies)
       this.rows=data.technologies
       this.rows=this.rows
     })
      this.columns = [
        { name: 'Wagon No.' },
        { name: 'owner' },
        { name: 'type' },
        { name: 'Built Date' },
        { name: 'Loaded Empty' },
        { name: 'Location from Ingine' },
        { name: 'POH Shop' },
        { name: 'POH Date' },
        { name: 'ROH Deport/Shop' },
        { name: 'ROH Date' },
        { name: 'Return Date' },
        { name: 'Derailed' },
        
      ];
  
  


    }



  

  

}
