import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { WagondetailsPage } from './wagondetails.page';
import { Ng2SmartTableModule } from 'ng2-smart-table';

const routes: Routes = [
  {
    path: '',
    component: WagondetailsPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    Ng2SmartTableModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [WagondetailsPage]
})
export class WagondetailsPageModule {}
