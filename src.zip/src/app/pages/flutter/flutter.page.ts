import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { HttpClient } from '@angular/common/http';
import { IBiodatas, User,Wagons } from '../../biodata';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-flutter',
  templateUrl: './flutter.page.html',
  styleUrls: ['./flutter.page.scss'],
})
export class FlutterPage implements OnInit {
  columns: ({ prop: string; name?: string; } | { name: string; prop?: string; })[];

  rows = []
  locations: any;
  ResArray: Wagons[];
  res: any;
  GridForm: any;
  name: string;
  bpc_no: string;
  row: any={}
  rake_id :number;
  WagonsArray: Wagons[];
  
  constructor(private formBuilder: FormBuilder, private http: HttpClient, private navCtrl: NavController,
    private restservice: AuthenticationService, private router: Router) {
  }

  onRenderItems(event) {
    console.log(`Moving item from ${event.detail.from} to ${event.detail.to}`);
    let draggedItem = this.ResArray.splice(event.detail.from, 1)[0];
    this.ResArray.splice(event.detail.to, 0, draggedItem)
    //this.ResArray = reorderArray(this.ResArray, event.detail.from, event.detail.to);
    event.detail.complete();
  }
  getList(res) {
    console.table(this.ResArray);
    var str = "4. IONIC"
    console.log(str.substring(3))
    str = '1. ' + str.substring(3)
    console.log(str)

  }
  searchTerm = ''
  showInputs=false
  setFilteredItems() {
    console.log('Hello i am Search Fun');
    if (this.searchTerm.length === 4) {

      this.restservice.setFilteredItems(this.searchTerm).subscribe((data: any) => {
        this.ResArray = data
        console.log(this.ResArray);
        console.log(data[0].rake_id);
        this.showInputs=true
        return data[0].rake_id
        /* var abs= data[0].rake_id;
        console.log('addddddddddddd',abs);

        this.addNewInputField(abs) */
        // this.restservice.ShowWagon().subscribe((data) =>{
        //   console.log('Rahul is here');
        //   console.log('wagons:',data)
        //   this.WagonsArray = data
        //   console.log(this.WagonsArray);
        //   }, error => {
        //     console.log('Error: ', error)
          
    
        //  })




      }, error => {
        console.log('Error: ', error)
      });
    }


    
  }

  EditButton(a) {
    console.log('Edit fun here');
    // console.log(this.ResArray);

    // item.editable = true;
    // console.log('To allow edit here', a)
    // a.hide = a.hide!
  }
  ngOnInit() {
  }

  allowEdit(a) {
    console.log('To allow edit here', a)
    a.hide = a.hide!
  }
  addNewInputField(rakeid) {
    console.log('inputfield here');
    console.log("data is:",this.row,rakeid);
    console.log("Print rake :",rakeid);
    console.log('This is return value:',this.setFilteredItems())

  this.restservice.postMethod(this.row).subscribe((data:any) => {
      
     
     console.log('Push Response Data:', data)
     this.restservice.ShowWagon().subscribe((data) =>{
      console.log('Rahul is here');
      console.log('wagons:',data)
      this.WagonsArray = data
      console.log(this.WagonsArray);
      }, error => {
        console.log('Error: ', error)
      

     })
    
      }) 

  }
}
