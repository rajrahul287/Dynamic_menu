import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic',
  templateUrl: './ionic.page.html',
  styleUrls: ['./ionic.page.scss'],
})
export class IonicPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
