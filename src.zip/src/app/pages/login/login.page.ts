import { Component, OnInit } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AuthenticationService } from '../../services/authentication.service';
import { map } from 'rxjs/operators';
import { BehaviorSubject, } from 'rxjs';
import { IBiodatas } from '../../biodata';
import { Observable } from 'rxjs/internal/Observable';
import { Local } from 'protractor/built/driverProviders';
import { Platform, NavController } from '@ionic/angular';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';


@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  data:string;
  public user_id: string;
  public loginpage = [
  ];
  errMsg = "";
  public userId: string;
  public password:string;
  userIdhtml: String;
  Passwordhtml: string;
  Username: string;
 

  constructor(private http: HttpClient, private navCtrl: NavController, private restservice: AuthenticationService,
    private router: Router, public toastController: ToastController) {

  }

  ngOnInit() {

  }
  login() {
   
    console.log('Username:-' + this.userIdhtml);
    console.log('Password:-' + this.Passwordhtml);
    if (this.userIdhtml != null ||  this.userIdhtml != undefined || this.Passwordhtml || this.Passwordhtml != undefined) {
       //this.presentToast("Please enter Email and Password.")

      console.log("Inside login(). Logins will be handle here.")
      this.restservice.login(this.userIdhtml)
      
      .subscribe((data :any) => {
        //console.log("1 this is data:",data)
        this.loginpage = data
        console.log("2",this.userIdhtml);
        console.log("3",this.Passwordhtml); 
        console.log("4",data.userId);
        console.log("5",data.password);
        
       
       if((this.userIdhtml == data.userId) && (this.Passwordhtml== data.password )) {
        
        
          this.showToast('Login Successful')
    
          this.router.navigateByUrl('menu');
          this.loginpage = data
          console.log(this.loginpage);
          console.log("login successful");
        
      }
      else {

        // this.Username = "";
        // this.password = "";
        this.errMsg = "Invalid Username/Password";
        this.showToast('user id and password incorrect');
      }
     
    },
        error => {
          console.log('Error: ', error)
          this.showToast('Invalid credintial')
        });
    }
    
  }
  showToast(message) {
    console.log(message)
    this.presentToast(message)
  }

  async presentToast(message) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000
    });
    toast.present();
  }

}
