import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { Platform } from '@ionic/angular';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { IBiodatas, User } from '../../biodata';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.page.html',
  styleUrls: ['./menu.page.scss'],
})
export class MenuPage implements OnInit {


  pages = [
    {
      title: 'Main',
      url: '/menu/main',
      icon: 'home',
      
    },
    {
      title: 'Submenu',
      children: [
        {
          title: 'child 1',
          url: '/menu/ionic',
          icon: 'logo-ionic'
        },
        {
          title: 'child 2',
          url: '/menu/flutter',
          icon: 'logo-google'
        },
      ]
    }
  ];


  jsondata: IBiodatas[];

  constructor(private platform: Platform, private splashScreen: SplashScreen,
    private statusBar: StatusBar, private http: HttpClient,
    private restservice: AuthenticationService, private router: Router) {


    console.log('loading  menu module');


  }

  ngOnInit() {
    console.log('loading json init');
    this.restservice.bioData().subscribe(data => {
      this.jsondata = data
      console.log(this.jsondata);
    }, error => {
      console.log('Error: ', error)
    });

  }
  

}