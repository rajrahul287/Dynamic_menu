import { Injectable, Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IBiodatas, User,Wagons } from '../biodata';
import { Observable } from 'rxjs/internal/Observable';
import { BehaviorSubject, of } from 'rxjs';
import { Platform, NavController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { ToastController } from '@ionic/angular';
import { catchError, tap } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
//apiURL='http://192.168.137.211:3000/roams-users/admin'

apiURL ='http://10.60.201.247:3001/api/RoamsUsers'

dnamicApi='http://192.168.137.211:3000/api/auth1s'
//SearchAPI ='http://192.168.137.211:3000/api/roams?filter={"where":{"bpc_no":"1111"}}'
addapi = 'http://192.168.137.211:3000/api/roams'
BpcAPI ='http://192.168.137.211:3001/api/roams_rake_details'


  
  navCtrl: any;
 
  rake_id:number;

  constructor(private storage: Storage, private plt: Platform,navCtrl: NavController, private http: HttpClient) {
   
  }

 
  bioData(): Observable<IBiodatas[]> {
    console.log('Data pahunch gya')
    return this.http.get<IBiodatas[]>(this.dnamicApi);

  }
  login(userIdhtml): Observable<User[]> {
    console.log('here in service ')
    return this.http.get<User[]>(this.apiURL+"/"+ userIdhtml);
  }
  setFilteredItems(searchTerm):Observable<Wagons[]> {
    console.log('Search data observeable')
    return this.http.get<Wagons[]>('http://192.168.137.211:3000/api/roams?filter={"where":{"bpc_no":"'+searchTerm+'"}}');

    

  }
  ShowWagon():Observable<Wagons[]> {
    console.log(' wagons in services')
    return this.http.get<Wagons[]>(this.addapi);

    

  }

  postMethod(data){
    console.log('Data to post is :',data)
    // data.creation_date=new Date().toISOString()
    return this.http.post<Wagons[]>('http://192.168.137.211:3001/api/roams_rake_details',data);
    
  }
  
}